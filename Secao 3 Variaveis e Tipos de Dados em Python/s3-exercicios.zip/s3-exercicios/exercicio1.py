"""
1. Faça um programa que leia um número inteiro e imprima-o.
"""

numero: int = int(input("Informe um numero inteiro: "))

print(numero)
