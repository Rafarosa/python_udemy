"""
2. Faça um programa que peça para o usuário digitar três valores inteiro e imprima a soma deles.
"""

numero1: int = int(input('Informe o primeiro inteiro: '))
numero2: int = int(input('Informe o segundo inteiro: '))
numero3: int = int(input('Informe o terceiro inteiro: '))

soma: int = numero1 + numero2 + numero3

print(f"A soma dos numeros {numero1} com {numero2} e {numero3} eh {soma}")
